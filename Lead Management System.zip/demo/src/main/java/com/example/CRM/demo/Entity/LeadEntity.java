package com.example.CRM.demo.Entity;



import jakarta.persistence.*;
import jakarta.persistence.Table;

@Entity
@Table(name = "leads")
public class LeadEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    private String phone;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LeadStatus status = LeadStatus.NEW; // Use the enum here
    
    @ManyToOne
    @JoinColumn(name = "project_id")
    private ProjectEntity project;
  
    public LeadEntity() {}
    
    public LeadEntity(String name, String email, String phone, LeadStatus status) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.status = status;
    }
    
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LeadStatus getStatus() { return status; }
    public void setStatus(LeadStatus status) { this.status = status; }
    
    public ProjectEntity getProject() { return project; }
    public void setProject(ProjectEntity project) { this.project = project; }
}