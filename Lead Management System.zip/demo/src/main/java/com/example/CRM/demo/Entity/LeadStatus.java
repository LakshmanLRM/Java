package com.example.CRM.demo.Entity;
public enum LeadStatus {
    NEW, 
    CONTACTED, 
    QUALIFIED, 
    LOST
}