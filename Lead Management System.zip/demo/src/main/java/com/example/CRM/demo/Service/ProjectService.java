package com.example.CRM.demo.Service;

import com.example.CRM.demo.Entity.LeadEntity;
import com.example.CRM.demo.Entity.ProjectEntity;
import com.example.CRM.demo.Repository.LeadRepository;
import com.example.CRM.demo.Repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProjectService {
    
    @Autowired
    private ProjectRepository projectRepository;
    
    @Autowired
    private LeadRepository leadRepository;

    public List<ProjectEntity> getAllProjects() {
        return projectRepository.findAll();
    }

    public Optional<ProjectEntity> getProjectById(Long id) {
        return projectRepository.findById(id);
    }

    public ProjectEntity saveProject(ProjectEntity project) {
        return projectRepository.save(project);
    }

    public void assignLeadToProject(Long projectId, Long leadId) {
        ProjectEntity project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        LeadEntity lead = leadRepository.findById(leadId)
                .orElseThrow(() -> new RuntimeException("Lead not found"));
        
        lead.setProject(project);
        leadRepository.save(lead);
    }

    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }
}