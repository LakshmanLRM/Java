package com.example.CRM.demo.Controller;

import com.example.CRM.demo.Entity.LeadEntity;
import com.example.CRM.demo.Entity.ProjectEntity;
import com.example.CRM.demo.Service.LeadService;
import com.example.CRM.demo.Service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class WebController {
    
    @Autowired
    private LeadService leadService;
    
    @Autowired
    private ProjectService projectService;

    @GetMapping("/")
    public String dashboard(Model model) {
        try {
            model.addAttribute("leads", leadService.getAllLeads());
            model.addAttribute("projects", projectService.getAllProjects());
            return "dashboard";
        } catch (Exception e) {
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
            return "dashboard";
        }
    }

    @GetMapping("/leads")
    public String showLeads(Model model) {
        try {
            model.addAttribute("leads", leadService.getAllLeads());
            model.addAttribute("lead", new LeadEntity());
            return "leads";
        } catch (Exception e) {
            model.addAttribute("error", "Error loading leads: " + e.getMessage());
            return "leads";
        }
    }

    @PostMapping("/leads")
    public String createLead(@ModelAttribute LeadEntity lead, RedirectAttributes redirectAttributes) {
        try {
            leadService.saveLead(lead);
            redirectAttributes.addFlashAttribute("success", "Lead created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error creating lead: " + e.getMessage());
        }
        return "redirect:/leads";
    }

    @PostMapping("/leads/{id}/delete")
    public String deleteLead(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            leadService.deleteLead(id);
            redirectAttributes.addFlashAttribute("success", "Lead deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting lead: " + e.getMessage());
        }
        return "redirect:/leads";
    }

    @GetMapping("/projects")
    public String showProjects(Model model) {
        try {
            model.addAttribute("projects", projectService.getAllProjects());
            model.addAttribute("project", new ProjectEntity());
            return "projects";
        } catch (Exception e) {
            model.addAttribute("error", "Error loading projects: " + e.getMessage());
            return "projects";
        }
    }

    @PostMapping("/projects")
    public String createProject(@ModelAttribute ProjectEntity project, RedirectAttributes redirectAttributes) {
        try {
            projectService.saveProject(project);
            redirectAttributes.addFlashAttribute("success", "Project created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error creating project: " + e.getMessage());
        }
        return "redirect:/projects";
    }

    @GetMapping("/projects/{id}")
    public String showProjectLeads(@PathVariable Long id, Model model) {
        try {
            Optional<ProjectEntity> project = projectService.getProjectById(id);
            if (project.isPresent()) {
                model.addAttribute("project", project.get());
                model.addAttribute("leads", leadService.getLeadsByProject(id));
                model.addAttribute("availableLeads", leadService.getAllLeads());
                return "project-leads";
            } else {
                return "redirect:/projects?error=Project not found";
            }
        } catch (Exception e) {
            return "redirect:/projects?error=Error loading project";
        }
    }

    @PostMapping("/projects/{projectId}/assign")
    public String assignLead(@PathVariable Long projectId, 
                           @RequestParam Long leadId,
                           RedirectAttributes redirectAttributes) {
        try {
            projectService.assignLeadToProject(projectId, leadId);
            redirectAttributes.addFlashAttribute("success", "Lead assigned successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error assigning lead: " + e.getMessage());
        }
        return "redirect:/projects/" + projectId;
    }

    @PostMapping("/projects/{id}/delete")
    public String deleteProject(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            projectService.deleteProject(id);
            redirectAttributes.addFlashAttribute("success", "Project deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting project: " + e.getMessage());
        }
        return "redirect:/projects";
    }
}