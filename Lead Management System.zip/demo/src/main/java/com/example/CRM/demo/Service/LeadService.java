package com.example.CRM.demo.Service;
import com.example.CRM.demo.Entity.LeadEntity;
import com.example.CRM.demo.Entity.LeadStatus;
import com.example.CRM.demo.Repository.LeadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class LeadService {
    
    @Autowired
    private LeadRepository leadRepository;

    public List<LeadEntity> getAllLeads() {
        return leadRepository.findAll();
    }

    public Optional<LeadEntity> getLeadById(Long id) {
        return leadRepository.findById(id);
    }

    public LeadEntity saveLead(LeadEntity lead) {
        if (lead.getId() == null && leadRepository.existsByEmail(lead.getEmail())) {
            throw new RuntimeException("Lead with this email already exists");
        }
        return leadRepository.save(lead);
    }

    public List<LeadEntity> getLeadsByStatus(LeadStatus status) {
        return leadRepository.findByStatus(status);
    }

    public List<LeadEntity> getLeadsByProject(Long projectId) {
        return leadRepository.findByProjectId(projectId);
    }

    public void deleteLead(Long id) {
        leadRepository.deleteById(id);
    }
}