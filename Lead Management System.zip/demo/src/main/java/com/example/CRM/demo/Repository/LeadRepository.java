package com.example.CRM.demo.Repository;
import com.example.CRM.demo.Entity.LeadEntity;
import com.example.CRM.demo.Entity.LeadStatus;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LeadRepository extends JpaRepository<LeadEntity, Long> {
    List<LeadEntity> findByStatus(LeadStatus status);
    List<LeadEntity> findByProjectId(Long projectId);
    boolean existsByEmail(String email);
}

