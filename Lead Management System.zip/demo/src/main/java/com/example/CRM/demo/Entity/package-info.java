package com.example.CRM.demo.Entity;
